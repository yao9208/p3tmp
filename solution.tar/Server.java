/* Sample code for basic Server */
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends UnicastRemoteObject{
	protected Server() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	public static void main ( String args[] ) throws Exception {
		if (args.length != 2) throw new Exception("Need 2 args: <cloud_ip> <cloud_port>");
		ServerLib SL = new ServerLib( args[0], Integer.parseInt(args[1]) );
		
		// register with load balancer so requests are sent to this server
		SL.register_frontend();
//		Master svr = new Master();
//		if(svr.isMaster()){
//			System.out.println("master---");
//			for(int i=0; i<5; i++){
//				SL.startVM();
//			}
//		}
		int hour = (int) SL.getTime();
		int instances = 2;
		switch(hour){
			case 6:
				instances=2;
				break;
			case 8:
				instances=3;
				break;
			case 19:
				instances=6;
				break;
			default:
				break;
		}
		
		// main loop
		while (true) {
			if(SL.getStatusVM(instances) == Cloud.CloudOps.VMStatus.NonExistent){
				SL.startVM();
			}
			Cloud.FrontEndOps.Request r = SL.getNextRequest();
			SL.processRequest( r );
		}
	}
	
}
class Master extends UnicastRemoteObject{

	protected Master() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	public boolean isMaster() throws AccessException, RemoteException, AlreadyBoundException{
		Master ms = (Master) UnicastRemoteObject.exportObject(this, 0);
		Registry registry = LocateRegistry.getRegistry();
		try {
			registry.bind("//127.0.1.1:15640/master", (Remote) this);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
}

